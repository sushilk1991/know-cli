# Codebase Digest

## Project Structure


## Statistics
- Files: 0
- Modules: 0
- Functions: 0
- Classes: 0

*Install anthropic package and set ANTHROPIC_API_KEY for AI-powered digests*